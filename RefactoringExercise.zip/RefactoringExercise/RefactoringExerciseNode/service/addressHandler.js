"use strict";

const CountryRepository = require('./countryRepository').CountryRepository;

exports.AddressHanler = {
    populateDetails: function (countryId, countryName, stateProvince, postalCode) {
        const result = {
            postalCode: postalCode
        };
        const errors = [];

        // Simulate a call to data storage
        const repo = new CountryRepository();
        const countries = repo.getCountries();

        if (countries && countries.length) {
            var countryIndex = -1;

            //Get the country info
            if (!(countryIndex >= 0)) {
                countryIndex = countries.findIndex(c => c.countryId === countryId);
            }

            if (!(countryIndex >= 0) && !countryName) {
                if (!(countryIndex >= 0)) {
                    //Try the name
                    countryIndex = countries.findIndex(c => c.name.toLowerCase() === countryName.toLowerCase());
                }
            }

            if (countryIndex >= 0) {
                //Set the country info
                result.country = countries[countryIndex];
            }

            //Enforce the Postal Code Requirement
            if (result.country.countryId && result.postalCode) {
                //Determine if postal codes are required for the country
                if (!(countryIndex >= 0)) {
                    //Identify the correct country record
                    countryIndex = countries.findIndex(function callbackFn(country) { return country.countryId === result.country.countryId });
                }

                if (countryIndex >= 0) {
                    if (countries[countryIndex].postalCodeRequired && countries[countryIndex].shortName === "US") {
                        //Postal code is required - add a validation failure
                        var isValid = ValidationHandler.validateString("postalCode", result.postalCode, true, true, true, -1, -1);
                        if (!isValid) {
                            errors.Add("postalCode");
                        }
                    }
                }
            }

            //Get the StateProvince Info

            //See if the country has state/provinces and create an error if it does
            if (!(countryIndex >= 0)) {
                //Identify the correct country record
                countryIndex = countries.findIndex(c => c.countryId === result.country.countryId);
            }

            if (countryIndex >= 0) {
                if (countries[countryIndex].stateProvinces.length > 0) {
                    //The country has state/provinces - try to finding the id using the id
                    var stateIndex = countries[countryIndex].stateProvinces.findIndex(s => stateProvince.stateProvinceId !== 0 && s.stateProvinceId === stateProvince.stateProvinceId);

                    if (!(stateIndex >= 0))
                        //Try to find the id using the name
                        stateIndex = countries[countryIndex].stateProvinces.findIndex(s => stateProvince.name && s.name === stateProvince.name);

                    if (stateIndex >= 0)
                        //Found the state
                        result.StateProvince = countries[countryIndex].stateProvinces[stateIndex];
                    else {
                        //Unable to find the id - create a validation failure
                        errors.push("stateProvinceId");
                    }
                }
            }
            else {
                //Unable to find a matching country - create a validation failure
                errors.push("addresscountry");
            }
        } else {
            errors.push('countries');
        }

        var firstValidationFailure = errors.length ? errors[0] : null;
        if (firstValidationFailure) {
            throw new RangeError(firstValidationFailure);
        }

        return result;
    }
};


exports.ValidationHandler = {
    validateString: function (propertyName, value, checkForNull, checkForEmpty, checkForCommas, maxLength, minLength) {
        var isNull = false,
            isEmpty = false,
            hasCommas = false,
            maxExceeded = false,
            lessThanMin = false;
        var isValid;

        var valueByRef = { value: value };
        var validStringResult = isValidString(valueByRef, checkForNull, checkForEmpty, checkForCommas, maxLength, minLength);
        isValid = validStringResult.isValid;
        isNull = validStringResult.isNull;
        isEmpty = validStringResult.isEmpty;
        hasCommas = validStringResult.hasCommas;
        maxExceeded = validStringResult.maxExceeded;
        lessThanMin = validStringResult.lessThanMin;

        if (propertyName === "postalCode") {
            isValid = isValidUsPostalCode(value);
        }

        return isValid;
    },
    isValidUsPostalCode: function (input) {
        if (!input) {
            throw new TypeError("input is null");
        }
        let re = new RegExp(/^\d{5}(-\\d{4})?$/);
        return re.test(input);
    },

    /// <summary>
    /// Checks input for the flagged parameters.
    /// </summary>
    /// <param name="input">The string to validate.</param>
    /// <param name="checkForNull">If set to true, the method returns false if the string is null.</param>
    /// <param name="checkForEmpty">If set to true, the method returns false if the string is an empty string.</param>
    /// <param name="checkForCommas">If set to true, the method returns false if the string contains any commas.</param>
    /// <param name="maxLength">If set to a positive integer, the method returns false if the string exceeds maxSize. 
    /// Setting maxSize to less than or equal to zero disables the maxSize check.</param>
    /// <param name="minLength"></param>
    /// <param name="isNull">Returns true if the string is null.</param>
    /// <param name="isEmpty">Returns true if the string is empty.</param>
    /// <param name="hasCommas">Returns true if the string has commas.</param>
    /// <param name="tooBig">Returns true if the string length exceeds <paramref name="maxLength"/>.</param>
    /// <param name="tooSmall">Returns true if the string length is less than <paramref name="minLength"/>.</param>
    /// <returns>true if input passes all the flagged parameters.  Returns false on the first check that fails.</returns>
    isValidString: function(input, checkForNull, checkForEmpty, checkForCommas, maxLength, minLength) {
        isNull = false;
        isEmpty = false;
        hasCommas = false;
        tooBig = false;
        tooSmall = false;

        if (input === null)
            isNull = true;

        else {

            input.value = input.value.trim();
            if (checkForEmpty && input.value.length < 1)
                isEmpty = true;

            if (maxLength && input.value.length > maxLength)
                tooBig = true;

            if (minLength && input.value.length < minLength)
                tooSmall = true;

            if (checkForCommas && input.value.indexOf(',') >= 0)
                hasCommas = true;
        }

        let isValid;
        if ((checkForNull && isNull) || isEmpty || tooBig || hasCommas || tooSmall)
            isValid = false;
        else
            isValid = true;

        return {
            isValid: isValid,
            isNull: isNull,
            isEmpty: isEmpty,
            hasCommas: hasCommas,
            maxExceeded: tooBig,
            lessThanMin: tooSmall
        }
    }
};