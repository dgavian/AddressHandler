(function () {
    'use strict';

    const chai = require('chai');
    const should = require('chai').should();

    const sut = require('../service/addressHandler').AddressHanler;

    describe('Address Handler Tests', function () {
        it('should return an address when PopulateDetails is called with matching inputs', function () {
            const matchingCountryId = 2,
                matchingStateProvince = {
                    stateProvinceId: 52
                };

            const actual = sut.populateDetails(matchingCountryId, null, matchingStateProvince, null);

            actual.should.exist;
        });
    });
}());