﻿using NUnit.Framework;

namespace RefactoringExercise.Test
{
    [TestFixture]
    public class AddressHandlerTests
    {
        // TODO: This is an example unit test that can (and probably should)
        // either go away or be reworked after refactoring.
        [Test]
        public void PopulateDetails_MatchingInputs_ReturnsAddress()
        {
            var matchingCountryId = 2;
            var matchingStateProvince = new StateProvince
            {
                StateProvinceId = 52
            };

            var actual = AddressHandler.PopulateDetails(matchingCountryId, null, matchingStateProvince, null);

            Assert.NotNull(actual);
        }
    }
}
