﻿namespace RefactoringExercise
{
    public class Address
    {
        public Country Country { get; set; }
        public string PostalCode { get; set; }
        public StateProvince StateProvince { get; set; }
    }
}
