﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace RefactoringExercise
{
    public static class AddressHandler
    {
        /*
            Requirements:
            1. If any of the following are not met, an exception of the appropriate type is thrown
                * Matching country must be found (matches either passed in id or name)
                * Postal code is required if the matching country is US*
                    ** If postal code is required it must be in the format ##### or #####-####
                * If matching country has state provinces, matching state province must be found
                * (matches either id or name of passed in state province)
            2. Address country should be set to matching country
            3. Address state province should be set to matching state province where applicable

            Use case(s):
            * Customer types in free form address, which is parsed/split by a tool
            * Upstream code does some pre-processing/massaging of the parsed address data
            * Calling code will have either an integer country id or a string that represents either a country name or abbreviation
            * (from the perspective of the consuming code, it could be either)
            * Calling code *may* have a StateProvince object
            * Calling code *may* have a zip code
            
            Hints/Suggestions
            * Nothing is off the table (code removal, moving things around,
            * method/class extraction, renaming, changing signatures, using modern language features, etc.) as long as the requirements are met.
            * There is a *major* clean-up/code-removal opportunity related to ValidationHandler
            * and its ValidString and IsValidString methods; suggestion is to focus on finding that first as it will make the rest of the task much easier.
            * Use the test project to add your own tests as you see fit; the existing tests may be removed or updated if necessitated by your refactoing.
            * Focus on cleaning up the code in this file (AddressHandler.cs); the DTOs and mock repository can be left as-is.
        */
        public static Address PopulateDetails(int addressCountryId, string addressCountryName, StateProvince addressStateProvince, string postalCode)
        {
            var result = new Address();
            result.PostalCode = postalCode;
            var errorList = new List<string>();

            // Simulate a call to data storage.
            var repo = new CountryRepository();
            var countries = repo.GetCountries();

            if (countries != null && countries.Count > 0)
            {
                int countryIndex = -1;

                #region Get the Country Info

                if (addressCountryId != 0)
                    countryIndex = countries.FindIndex(c => c.CountryId.Equals(addressCountryId));

                if (!(countryIndex >= 0) && (!string.IsNullOrEmpty(addressCountryName)))
                {
                    if (!(countryIndex >= 0))
                        //Try the name
                        countryIndex = countries.FindIndex(c => !string.IsNullOrWhiteSpace(addressCountryName) && c.Name.Equals(addressCountryName, StringComparison.CurrentCultureIgnoreCase));
                }

                if (countryIndex >= 0)
                    //Set the country info
                    result.Country = countries[countryIndex];

                #endregion

                #region Enforce the Postal Code Requirement

                if (result.Country.CountryId != 0 && string.IsNullOrEmpty(result.PostalCode))
                {
                    //Determine if postal codes are required for the country
                    if (!(countryIndex >= 0))
                        //Identify the correct country record
                        countryIndex = countries.FindIndex(delegate (Country country) { return country.CountryId.Equals(result.Country.CountryId); });

                    if (countryIndex >= 0)
                    {
                        if (countries[countryIndex].PostalCodeRequired && countries[countryIndex].ShortName == "US")
                        {
                            //Postal code is required - add a validation failure
                            var isValid = ValidationHandler.ValidString("PostalCode", result.PostalCode, true, true, true, -1, -1);
                            if (!isValid)
                            {
                                errorList.Add("PostalCode");
                            }
                        }
                    }
                }

                #endregion

                #region Get the StateProvince Info

                //See if the country has state/provinces and create an error if it does
                if (!(countryIndex >= 0))
                    //Identify the correct country record
                    countryIndex = countries.FindIndex(c => c.CountryId.Equals(result.Country.CountryId));

                if (countryIndex >= 0)
                {
                    if (countries[countryIndex].StateProvinces.Count > 0)
                    {
                        //The country has state/provinces - try to finding the id using the id
                        int stateIndex = countries[countryIndex].StateProvinces.FindIndex(s => addressStateProvince.StateProvinceId != 0 && s.StateProvinceId.Equals(addressStateProvince.StateProvinceId));

                        if (!(stateIndex >= 0))
                            //Try to find the id using the name
                            stateIndex = countries[countryIndex].StateProvinces.FindIndex(s => !string.IsNullOrWhiteSpace(addressStateProvince.Name) && s.Name.Equals(addressStateProvince.Name, StringComparison.CurrentCultureIgnoreCase));

                        if (stateIndex >= 0)
                            //Found the state
                            result.StateProvince = countries[countryIndex].StateProvinces[stateIndex];
                        else
                        {
                            //Unable to find the id - create a validation failure
                            errorList.Add("StateProvinceId");
                        }
                    }
                }
                else
                {
                    //Unable to find a matching country - create a validation failure
                    errorList.Add("AddressCountry");
                }

                #endregion
            }
            else
            {
                //Unable to retrieve countries - create a validation failure
                errorList.Add("countries");
            }

            var firstValidationFailure = errorList.FirstOrDefault();

            if (firstValidationFailure != null)
            {
                throw new IndexOutOfRangeException(firstValidationFailure);
            }

            return result;
        }
    }

    public static class ValidationHandler
    {
        #region ValidString

        /// <summary>
        /// Validates the string value against the supplied parameters.
        /// </summary>
        /// <param name="propertyName">The name of the property being validated.</param>
        /// <param name="value">The value of the property being validated.</param>
        /// <param name="checkForNull">If set to true, validation will fail if the value is null.</param>
        /// <param name="checkForEmpty">If set to true, validation will fail if the value is empty.</param>
        /// <param name="checkForCommas">If set to true, validation will fail if the value contains commas.</param>
        /// <param name="maxLength">If set to a positive integer, validation will fail if the value exceeds maxLength.</param>
        /// <param name="minLength">If set to a positive integer, validation will fail if the value is less than minLength.</param>
        /// <param name="failureDetails">A <see cref="ValidationFailure"/> object with the results if the validation fails.  Otherwise, null.</param>
        /// <returns>true if the string passes validation.  Otherwise, returns false.</returns>
        public static bool ValidString(string propertyName, string value, bool checkForNull, bool checkForEmpty,
            bool checkForCommas, int maxLength, int minLength)
        {
            bool isNull, isEmpty, hasCommas, maxExceeded, lessThanMin;

            bool isValid = IsValidString(ref value, checkForNull, checkForEmpty, checkForCommas, maxLength, minLength, out isNull, out isEmpty, out hasCommas, out maxExceeded, out lessThanMin);
            if (propertyName == "PostalCode")
            {
                isValid = IsValidUsPostalCode(value);
            }

            return isValid;
        }

        #endregion

        public static bool IsValidUsPostalCode(string input)
        {
            if (input == null)
            {
                throw new ArgumentNullException(nameof(input));
            }
            var pattern = @"^\d{5}(-\d{4})?$";
            return Regex.IsMatch(input, pattern);
        }

        /// <summary>
        /// Checks input for the flagged parameters.
        /// </summary>
        /// <param name="input">The string to validate.</param>
        /// <param name="checkForNull">If set to true, the method returns false if the string is null.</param>
        /// <param name="checkForEmpty">If set to true, the method returns false if the string is an empty string.</param>
        /// <param name="checkForCommas">If set to true, the method returns false if the string contains any commas.</param>
        /// <param name="maxLength">If set to a positive integer, the method returns false if the string exceeds maxSize. 
        /// Setting maxSize to less than or equal to zero disables the maxSize check.</param>
        /// <param name="minLength"></param>
        /// <param name="isNull">Returns true if the string is null.</param>
        /// <param name="isEmpty">Returns true if the string is empty.</param>
        /// <param name="hasCommas">Returns true if the string has commas.</param>
        /// <param name="tooBig">Returns true if the string length exceeds <paramref name="maxLength"/>.</param>
        /// <param name="tooSmall">Returns true if the string length is less than <paramref name="minLength"/>.</param>
        /// <returns>true if input passes all the flagged parameters.  Returns false on the first check that fails.</returns>
        public static bool IsValidString(ref string input, bool checkForNull, bool checkForEmpty, bool checkForCommas, int maxLength, int minLength, out bool isNull, out bool isEmpty, out bool hasCommas, out bool tooBig, out bool tooSmall)
        {
            isNull = false;
            isEmpty = false;
            hasCommas = false;
            tooBig = false;
            tooSmall = false;

            if (input == null)
                isNull = true;
            else
            {

                input = input.Trim();
                if (checkForEmpty && input.Length < 1)
                    isEmpty = true;

                if (maxLength > 0 && input.Length > maxLength)
                    tooBig = true;

                if (minLength > 0 && input.Length < minLength)
                    tooSmall = true;

                if (checkForCommas && input.Contains(","))
                    hasCommas = true;
            }

            if ((checkForNull && isNull) || isEmpty || tooBig || hasCommas || tooSmall)
                return false;
            else
                return true;
        }
    }
}
